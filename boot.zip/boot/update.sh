#!/bin/sh
echo "32" > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio32/direction
echo "1" > /sys/class/gpio/gpio32/value
usleep 250000
echo "0" > /sys/class/gpio/gpio32/value
usleep 250000
echo "1" > /sys/class/gpio/gpio32/value
usleep 250000
echo "0" > /sys/class/gpio/gpio32/value
usleep 250000
echo "1" > /sys/class/gpio/gpio32/value
usleep 250000
echo "0" > /sys/class/gpio/gpio32/value

cp /udisk/boot/eth0-setting /etc/ -a
mkdir -p /data

if [ -e /udisk/boot/socket_server ]; then
	cp -a /udisk/boot/socket_server /
fi

if [ -e /udisk/boot/wftp ]; then
	cp -a /udisk/boot/wftp /
fi

if [ -e /udisk/boot/syscfg.ini ]; then
	cp -a /udisk/boot/syscfg.ini /data
fi
if [ -e /udisk/boot/rcS ]; then
	cp -a /udisk/boot/rcS /etc/init.d/rcS
fi

sync

. /etc/init.d/ifconfig-eth0


if [ -e /udisk/boot/zImage ]; then
sleep 2
flash_erase /dev/mtd1 0 0
nandwrite -p /dev/mtd1 /udisk/boot/zImage
sleep 2
fi

echo "1" > /sys/class/gpio/gpio32/value
usleep 500000
echo "0" > /sys/class/gpio/gpio32/value
usleep 500000
echo "1" > /sys/class/gpio/gpio32/value
usleep 500000
echo "0" > /sys/class/gpio/gpio32/value
usleep 500000
echo "1" > /sys/class/gpio/gpio32/value
usleep 500000
echo "0" > /sys/class/gpio/gpio32/value

echo "update completed!" > /dev/tty1
echo "32" > /sys/class/gpio/unexport
